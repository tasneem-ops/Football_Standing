package com.example.footballstanding.repository

import com.example.footballstanding.network.FootballApi

class LeagueRepo {
suspend fun getLeague() =  FootballApi.retrofitService.getProperties()
}