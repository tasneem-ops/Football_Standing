package com.example.footballstanding.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.footballstanding.databinding.ItemLayoutBinding
import com.example.footballstanding.network.League

class MyListAdapter : ListAdapter<League, MyListAdapter.LeagueViewHolder>(DiffCallback){
    companion object DiffCallback: DiffUtil.ItemCallback <League>(){
        override fun areItemsTheSame(oldItem: League, newItem: League): Boolean {
            return oldItem === newItem
        }

        override fun areContentsTheSame(oldItem: League, newItem: League): Boolean {
            return oldItem.id == newItem.id
        }
    }
    class LeagueViewHolder(private var binding : ItemLayoutBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(marsProperty: League){
            binding.football = marsProperty
            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LeagueViewHolder {
        return LeagueViewHolder(ItemLayoutBinding.inflate(LayoutInflater.from(parent.context)))
    }

    override fun onBindViewHolder(holder: LeagueViewHolder, position: Int) {
        val marsProperty =  getItem(position)
        holder.bind(marsProperty)
    }
}