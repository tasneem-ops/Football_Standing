package com.example.footballstanding.network

data class League (val id : String , val name: String , val slug : String, val abbr : String , val logos: Logos)

data class ApiModel(val status : Boolean , val data : List<League>)
data class Logos(val dark : String , val light : String )