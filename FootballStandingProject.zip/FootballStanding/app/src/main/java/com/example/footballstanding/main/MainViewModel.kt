package com.example.footballstanding.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.footballstanding.network.League
import com.example.footballstanding.repository.LeagueRepo
import kotlinx.coroutines.launch


class MainViewModel : ViewModel() {
private val _football = MutableLiveData<List<League>>()
    val football : LiveData<List<League>>
    get() = _football
    val repo = LeagueRepo()
    init {
        getLeague()
    }
fun getLeague(){
    viewModelScope.launch {
        _football.value = repo.getLeague().data
    }
}
}